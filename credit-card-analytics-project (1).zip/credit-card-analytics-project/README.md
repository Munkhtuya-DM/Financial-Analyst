# 💳 Credit Card Financial Analytics Project

## 📌 Summary
This project presents a comprehensive financial analysis of a credit card company's customer and transaction data using **SQL**, **Python**, and **Tableau**. It simulates a real-world data analytics scenario where the goal is to extract insights, optimize customer segmentation, and support business strategy with data-driven recommendations.

The project demonstrates strong **EDA**, data engineering, and storytelling skills — tailored for stakeholders in finance, marketing, and customer success teams.

## 🧰 Tools & Technologies
- **SQL Server / PostgreSQL** – Data cleaning, joining, aggregation
- **Python (Pandas, Seaborn, Matplotlib)** – Exploratory Data Analysis (EDA), feature engineering
- **Tableau** – Interactive dashboards and executive visual reports
- **Git & GitHub** – Version control and project documentation

## 🔍 Key Analysis Areas
- **Customer Segmentation** by demographics, income, education, and job
- **Revenue & Profitability Trends** across card tiers and transaction types
- **Churn Risk Modeling** based on engagement and transaction history
- **Customer Lifetime Value Estimation** using RFM-based logic
- **Card Tier Optimization** suggesting upgrades/downgrades by behavior

## 📈 Dashboards & Visual Insights
- Revenue by expenditure type, education, job, and card category
- Customer acquisition cost per tier
- Quarterly transaction trends and churn patterns
- Geographic analysis by top-performing states

## ✅ Project Deliverables
- Cleaned and joined datasets using SQL
- EDA and advanced metrics generation in Python
- Visualized key insights via Tableau dashboards
- GitHub-ready project structure with `.ipynb`, `.sql`, and `.pdf` files

## 🧠 Skills Demonstrated
- End-to-end financial data analysis
- SQL and Python proficiency
- Advanced EDA and business reporting
- Data visualization and stakeholder storytelling
- Real-world problem-solving and project packaging

## 📬 Contact
Made with ❤️ by [Your Name] · [LinkedIn](#) · [Portfolio](#)
